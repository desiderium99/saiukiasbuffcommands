from pathlib import Path
import zipfile
root=Path(__file__).resolve().parent
output=root/'build/HytaleBuffCommands-2.2.1.jar'
output.parent.mkdir(exist_ok=True)
resources=root/'src/main/resources'
with zipfile.ZipFile(root/'lib/HytaleBuffCommands-2.2.0.jar') as base, zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as out:
    for n in base.namelist():
        if not n.endswith('/'):
            override=resources/n
            out.writestr(n,override.read_bytes() if override.is_file() else base.read(n))
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
print(output)
