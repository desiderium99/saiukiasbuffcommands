Hytale Buff Commands 2.2.1 - available source and development files

This is NOT a complete Java source tree for 2.2.1.
The supplied 2.2.0 development archive contains only DefenseSupport.java,
DefenseSystem.java and Patch.java. The original source for BuffCommandsPlugin,
IncrementSupport and TargetSupport was not included in that archive.

src/main/resources: exact editable 2.2.1 UI and manifest.
available-java: Java source supplied in the 2.2.0 development archive.
lib: original 2.2.0 compiled JAR, used to preserve all gameplay behavior.
reference: older 2.0.1 source archive; not the current implementation.

Rebuild the 2.2.1 resource update with Python 3: python build.py
Result: build/HytaleBuffCommands-2.2.1.jar
No Java compilation is performed. The existing compiled gameplay classes are
retained unchanged. Editing available-java does not change this build.
Do not run Patch.java on the already patched 2.2.0 base.
