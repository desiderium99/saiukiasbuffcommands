package dev.local.buffcommands;
import java.util.*;import java.util.regex.*;import java.nio.file.*;import java.io.*;
import com.hypixel.hytale.component.*;
import com.hypixel.hytale.server.core.universe.*;
import com.hypixel.hytale.server.core.universe.world.storage.*;
import com.hypixel.hytale.server.core.modules.entity.damage.*;
import com.hypixel.hytale.server.core.ui.builder.*;
import com.hypixel.hytale.protocol.packets.interface_.CustomUIEventBindingType;
public final class DefenseSupport {
 private static final Map<UUID,Integer> resistance=new HashMap<>(); private static final Set<UUID> invincible=new HashSet<>();
 private static final Path file=Path.of("mods","BuffCommands-defense.properties");
 private static final Pattern action=Pattern.compile("\\\"?Action\\\"?\\s*:\\s*\\\"([A-Za-z0-9_]+)\\\"");
 static{load();}
 private static synchronized void load(){try{if(!Files.isRegularFile(file))return;Properties p=new Properties();try(InputStream in=Files.newInputStream(file)){p.load(in);}for(String k:p.stringPropertyNames()){try{UUID id=UUID.fromString(k.substring(2));if(k.startsWith("r.")) resistance.put(id,Math.max(0,Math.min(100,Integer.parseInt(p.getProperty(k)))));else if(k.startsWith("i.") && Boolean.parseBoolean(p.getProperty(k)))invincible.add(id);}catch(Exception ignored){}}}catch(Exception e){System.err.println("[BuffCommands] Defense load failed "+e);}}
 private static synchronized void save(){try{Files.createDirectories(file.getParent());Properties p=new Properties();resistance.forEach((id,v)->p.setProperty("r."+id,v.toString()));invincible.forEach(id->p.setProperty("i."+id,"true"));try(OutputStream out=Files.newOutputStream(file)){p.store(out,"Buff Commands defense");}}catch(Exception e){System.err.println("[BuffCommands] Defense save failed "+e);}}
 private static boolean isAll(Object page){try{var f=IncrementSupport.class.getDeclaredField("all");f.setAccessible(true);return ((Set<?>)f.get(null)).contains(page);}catch(Exception e){return false;}}
 public static void bind(Object page,UIEventBuilder events,UICommandBuilder commands){for(String id:new String[]{"Resist10","Resist25","Resist50","ResistReset","InvincibleOn","InvincibleOff"})events.addEventBinding(CustomUIEventBindingType.Activating,"#"+id,EventData.of("Action",id),false);}
 public static boolean act(Object page,Object ref,Object store,String raw){if(raw==null||raw.length()>512)return false;Matcher m=action.matcher(raw);if(!m.find())return false;String a=m.group(1);if(!Set.of("Resist10","Resist25","Resist50","ResistReset","InvincibleOn","InvincibleOff").contains(a))return false;
 try{java.util.List<Object> targets=isAll(page)?TargetSupport.players(page):java.util.Collections.singletonList(TargetSupport.target(page));int count=0;
 for(Object p:targets){if(p==null)continue;UUID id=TargetSupport.id(p);synchronized(DefenseSupport.class){switch(a){case "Resist10"->resistance.put(id,10);case "Resist25"->resistance.put(id,25);case "Resist50"->resistance.put(id,50);case "ResistReset"->resistance.remove(id);case "InvincibleOn"->invincible.add(id);case "InvincibleOff"->invincible.remove(id);}save();}count++;}
 UICommandBuilder c=new UICommandBuilder();c.set("#Hint.Text",a+" applied to "+count+" player(s)");TargetSupport.call(page,"sendUpdate",c);System.out.println("[BuffCommands] "+a+" applied to "+count+" players");
 }catch(Exception e){System.err.println("[BuffCommands] Defense click failed: "+e);e.printStackTrace();}return true;}
 public static void apply(int index,ArchetypeChunk<EntityStore> chunk,Store<EntityStore> store,Damage event){
 try{var ref=chunk.getReferenceTo(index);PlayerRef player=store.getComponent(ref,PlayerRef.getComponentType());if(player==null)return;UUID id=player.getUuid();int reduction;boolean immune;
 synchronized(DefenseSupport.class){reduction=resistance.getOrDefault(id,0);immune=invincible.contains(id);}
 if(immune){event.setAmount(0f);event.removeMetaObject(Damage.KNOCKBACK_COMPONENT);event.setCancelled(true);return;}
 if(reduction>0&&event.getAmount()>0)event.setAmount(event.getAmount()*(100-reduction)/100f);
 }catch(Exception e){System.err.println("[BuffCommands] Damage filtering failed "+e);}
 }
}
