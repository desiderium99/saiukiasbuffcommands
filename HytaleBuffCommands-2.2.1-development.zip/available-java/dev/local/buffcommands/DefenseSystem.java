package dev.local.buffcommands;
import com.hypixel.hytale.component.*;
import com.hypixel.hytale.component.query.*;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import com.hypixel.hytale.server.core.modules.entity.damage.*;
public final class DefenseSystem extends DamageEventSystem {
 public SystemGroup<EntityStore> getGroup(){return DamageModule.get().getFilterDamageGroup();}
 public Query<EntityStore> getQuery(){return Query.any();}
 public void handle(int index,ArchetypeChunk<EntityStore> chunk,Store<EntityStore> store,CommandBuffer<EntityStore> buffer,Damage event){if(!event.isCancelled())DefenseSupport.apply(index,chunk,store,event);}
}
