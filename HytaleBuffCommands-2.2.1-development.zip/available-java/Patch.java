import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
public class Patch{
 static byte[] patch(byte[] bytes,String kind){ClassReader r=new ClassReader(bytes);ClassWriter w=new ClassWriter(r,ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS);r.accept(new ClassVisitor(Opcodes.ASM8,w){
 @Override public MethodVisitor visitMethod(int access,String name,String desc,String signature,String[] exceptions){MethodVisitor mv=super.visitMethod(access,name,desc,signature,exceptions);
 boolean doBuild=kind.equals("menu")&&name.equals("build")&&desc.startsWith("(Lcom/hypixel/hytale/component/Ref;");
 boolean doHandle=kind.equals("menu")&&name.equals("handleDataEvent")&&desc.endsWith("Ljava/lang/String;)V");
 boolean doSetup=kind.equals("plugin")&&name.equals("setup")&&desc.equals("()V");
 if(!doBuild&&!doHandle&&!doSetup)return mv;
 return new MethodVisitor(Opcodes.ASM8,mv){@Override public void visitCode(){super.visitCode();if(doBuild){mv.visitVarInsn(Opcodes.ALOAD,0);mv.visitVarInsn(Opcodes.ALOAD,3);mv.visitVarInsn(Opcodes.ALOAD,2);mv.visitMethodInsn(Opcodes.INVOKESTATIC,"dev/local/buffcommands/DefenseSupport","bind","(Ljava/lang/Object;Lcom/hypixel/hytale/server/core/ui/builder/UIEventBuilder;Lcom/hypixel/hytale/server/core/ui/builder/UICommandBuilder;)V",false);}
 if(doHandle){Label next=new Label();mv.visitVarInsn(Opcodes.ALOAD,0);mv.visitVarInsn(Opcodes.ALOAD,1);mv.visitVarInsn(Opcodes.ALOAD,2);mv.visitVarInsn(Opcodes.ALOAD,3);mv.visitMethodInsn(Opcodes.INVOKESTATIC,"dev/local/buffcommands/DefenseSupport","act","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)Z",false);mv.visitJumpInsn(Opcodes.IFEQ,next);mv.visitInsn(Opcodes.RETURN);mv.visitLabel(next);}
 if(doSetup){mv.visitVarInsn(Opcodes.ALOAD,0);mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL,"dev/local/buffcommands/BuffCommandsPlugin","getEntityStoreRegistry","()Lcom/hypixel/hytale/component/ComponentRegistryProxy;",false);mv.visitTypeInsn(Opcodes.NEW,"dev/local/buffcommands/DefenseSystem");mv.visitInsn(Opcodes.DUP);mv.visitMethodInsn(Opcodes.INVOKESPECIAL,"dev/local/buffcommands/DefenseSystem","<init>","()V",false);mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL,"com/hypixel/hytale/component/ComponentRegistryProxy","registerSystem","(Lcom/hypixel/hytale/component/system/ISystem;)V",false);}
 }};
 }
 },0);return w.toByteArray();}
 public static void main(String[] args)throws Exception{Path dir=Path.of(args[0]);Path menu=dir.resolve("dev/local/buffcommands/BuffCommandsPlugin$BuffMenu.class");Path plugin=dir.resolve("dev/local/buffcommands/BuffCommandsPlugin.class");Files.write(menu,patch(Files.readAllBytes(menu),"menu"));Files.write(plugin,patch(Files.readAllBytes(plugin),"plugin"));}
}
