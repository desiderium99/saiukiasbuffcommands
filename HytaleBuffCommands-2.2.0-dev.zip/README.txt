Hytale Buff Commands v2.2.0
============================
Requires server compatible with existing v2.1.2 server API (Hytale 0.7.2).
Install: remove all older versions of HytaleBuffCommands*.jar from the mods folder, upload HytaleBuffCommands-2.2.0.jar and restart.

GUI: /buff
Resistance: 10%, 25%, 50%, Normal. Applies damage reduction to incoming Damage events.
Invincibility: Invincible ON / Invincible OFF. Invincibility cancels incoming Damage events and clears knockback metadata attached to those attack events.
Player scope: use existing player selection or ALL PLAYERS.
Persists defensive settings in mods/BuffCommands-defense.properties.
All prior 2.1.2 commands and GUI controls are included.

LIMITATIONS: Cannot runtime test on the actual game host; verified compilation of new handlers against the provided server API and JAR archive integrity. Knockback generated separately from the damage event (scripted movement, environmental knockback, custom mods) may not be suppressed. If the 0.7.2 client fails to render the newly added rows or you see class verification errors, provide server/client logs.
